package api.endpoints;

public class EndPointURLs {

    public static String base_url = "http://100.76.208.239:32485/bcws/webresources/v1.0/telenor";
    public static String createBA_Post_url = base_url+"/account/createAccount";
    public static String get_AccInfo_url = base_url+"/account/getAccountInfo/{username}";


}
