package api.endpoints;


import org.testng.annotations.BeforeClass;
import utility.ConfigDataProvider;
import utility.ExcelDataProvider;
import java.io.FileNotFoundException;



public class BaseClass {

    public static ConfigDataProvider config;
    public static ExcelDataProvider excel;

    @BeforeClass
    public void setup() throws FileNotFoundException {

        config = new ConfigDataProvider();
        excel = new ExcelDataProvider();

    }
}